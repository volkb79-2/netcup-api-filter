"""
Reusable helpers for seeding default admin and demo accounts.

Updated for Account → Realms → Tokens architecture.
"""
from __future__ import annotations

import logging
import os
import secrets
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, List, Sequence, Tuple

from ..models import (
    Account,
    AccountRealm,
    ActivityLog,
    APIToken,
    USER_ALIAS_LENGTH,
    db,
    generate_token,
    generate_user_alias,
    hash_token,
    validate_username,
)
from ..config_defaults import get_default, load_defaults, require_default

logger = logging.getLogger(__name__)

_ENV_DEFAULTS = load_defaults()


@dataclass
class AdminSeedOptions:
    """Options for seeding admin account."""
    username: str = None
    password: str = None
    email: str = None
    must_change_password: bool = True
    
    def __post_init__(self):
        if self.username is None:
            self.username = require_default("DEFAULT_ADMIN_USERNAME")
        if self.password is None:
            self.password = require_default("DEFAULT_ADMIN_PASSWORD")
        if self.email is None:
            self.email = get_default("DEFAULT_ADMIN_EMAIL", "admin@localhost")


@dataclass
class RealmSeedOptions:
    """Options for seeding a realm."""
    domain: str
    realm_type: str = "host"  # host, subdomain, zone
    realm_value: str = ""  # Subdomain prefix or empty for apex
    record_types: Sequence[str] = field(default_factory=lambda: ["A", "AAAA"])
    operations: Sequence[str] = field(default_factory=lambda: ["read"])


@dataclass
class TokenSeedOptions:
    """Options for seeding a token."""
    token_name: str
    description: str = ""
    record_types: Sequence[str] | None = None  # None = inherit from realm
    operations: Sequence[str] | None = None  # None = inherit from realm
    ip_ranges: Sequence[str] | None = None


@dataclass
class DemoAccountSeedOptions:
    """Options for seeding a demo account with realm and token."""
    username: str
    password: str
    email: str = None
    realm: RealmSeedOptions = None
    token: TokenSeedOptions = None
    
    def __post_init__(self):
        if self.email is None:
            self.email = f"{self.username}@example.com"


# Backwards compatibility aliases
ClientSeedOptions = TokenSeedOptions


def ensure_admin_account(options: AdminSeedOptions) -> Account:
    """Create or update admin account.
    
    Returns:
        The admin Account object
    """
    account = Account.query.filter_by(username=options.username).first()
    if not account:
        # Generate unique user_alias for token attribution
        user_alias = generate_user_alias()
        account = Account(
            username=options.username,
            user_alias=user_alias,
            email=options.email,
            email_verified=1,
            email_2fa_enabled=1,
            is_active=1,
            is_admin=1,
            approved_at=datetime.utcnow()
        )
        account.set_password(options.password)
        account.must_change_password = 1 if options.must_change_password else 0
        db.session.add(account)
        logger.info(f"Created admin account: {options.username} (alias: {user_alias[:4]}...)")
    else:
        # Ensure existing account has user_alias
        if not account.user_alias:
            account.user_alias = generate_user_alias()
            logger.info(f"Added user_alias to existing admin: {options.username}")
        logger.info(f"Admin account {options.username} already exists, keeping existing settings")
    return account


# Backwards compatibility alias
ensure_admin_user = ensure_admin_account


def ensure_account(options: DemoAccountSeedOptions, approved_by: Account = None) -> Account:
    """Create or update a user account.
    
    Returns:
        The Account object
    """
    account = Account.query.filter_by(username=options.username).first()
    if not account:
        # Generate unique user_alias for token attribution
        user_alias = generate_user_alias()
        account = Account(
            username=options.username,
            user_alias=user_alias,
            email=options.email,
            email_verified=1,
            email_2fa_enabled=1,
            is_active=1,
            is_admin=0,
            approved_by_id=approved_by.id if approved_by else None,
            approved_at=datetime.utcnow()
        )
        account.set_password(options.password)
        db.session.add(account)
        logger.info(f"Created account: {options.username} (alias: {user_alias[:4]}...)")
    else:
        # Ensure existing account has user_alias
        if not account.user_alias:
            account.user_alias = generate_user_alias()
            logger.info(f"Added user_alias to existing account: {options.username}")
        logger.info(f"Account {options.username} already exists")
    return account


def ensure_realm(account: Account, options: RealmSeedOptions, approved_by: Account = None) -> AccountRealm:
    """Create or update a realm for an account.
    
    Returns:
        The AccountRealm object
    """
    # Check if realm already exists
    realm = AccountRealm.query.filter_by(
        account_id=account.id,
        domain=options.domain,
        realm_type=options.realm_type,
        realm_value=options.realm_value
    ).first()
    
    if not realm:
        realm = AccountRealm(
            account_id=account.id,
            domain=options.domain,
            realm_type=options.realm_type,
            realm_value=options.realm_value,
            status='approved',
            requested_at=datetime.utcnow(),
            approved_by_id=approved_by.id if approved_by else None,
            approved_at=datetime.utcnow()
        )
        realm.set_allowed_record_types(list(options.record_types))
        realm.set_allowed_operations(list(options.operations))
        db.session.add(realm)
        logger.info(f"Created realm: {options.realm_type}:{options.realm_value}@{options.domain}")
    else:
        logger.info(f"Realm already exists for {account.username}")
    
    return realm


def ensure_token(realm: AccountRealm, options: TokenSeedOptions) -> Tuple[APIToken, str]:
    """Create a token for a realm.
    
    Returns:
        Tuple of (APIToken object, plain token string)
    """
    # Check if token with same name exists
    existing = APIToken.query.filter_by(
        realm_id=realm.id,
        token_name=options.token_name
    ).first()
    
    if existing:
        logger.info(f"Token {options.token_name} already exists, skipping")
        return existing, None  # Can't return plain token for existing
    
    # Generate token using user_alias (not username for security)
    account = realm.account
    full_token = generate_token(account.user_alias)
    
    # Extract prefix (first 8 chars of random part)
    # Token format: naf_<user_alias>_<random64> where user_alias is 16 chars
    random_part_start = 4 + USER_ALIAS_LENGTH + 1  # "naf_" + alias + "_"
    token_prefix = full_token[random_part_start:random_part_start + 8]
    
    token = APIToken(
        realm_id=realm.id,
        token_name=options.token_name,
        token_description=options.description,
        token_prefix=token_prefix,
        token_hash=hash_token(full_token),
        is_active=1
    )
    
    # Optional overrides
    if options.record_types:
        token.set_allowed_record_types(list(options.record_types))
    if options.operations:
        token.set_allowed_operations(list(options.operations))
    if options.ip_ranges:
        token.set_allowed_ip_ranges(list(options.ip_ranges))
    
    db.session.add(token)
    logger.info(f"Created token: {options.token_name} for realm {realm.id}")
    
    return token, full_token


# Legacy compatibility - no-op, new schema doesn't use this
def ensure_client(options):
    """Legacy compatibility stub. New schema uses ensure_account + ensure_realm + ensure_token."""
    logger.warning("ensure_client() is deprecated - use ensure_account/ensure_realm/ensure_token instead")
    return None


def generate_test_client_credentials() -> Tuple[str, str]:
    """Generate secure random credentials for test account.
    
    Returns:
        Tuple of (username, token)
    """
    # Generate random username suffix
    random_suffix = secrets.token_urlsafe(6)[:8].lower()
    username = f"test_{random_suffix}"
    
    # For new schema, token is generated when creating the actual token
    # This returns a placeholder password for the account
    password = secrets.token_urlsafe(16)
    
    return username, password


def create_default_test_client_options() -> TokenSeedOptions:
    """Create default test token options."""
    return TokenSeedOptions(
        token_name="test-token",
        description=_ENV_DEFAULTS.get("DEFAULT_TEST_CLIENT_DESCRIPTION", "Sample read-only token"),
    )


def seed_demo_audit_logs(account: Account = None) -> None:
    """Seed demo audit logs for testing."""
    import json
    from datetime import timedelta
    
    # Only seed if no logs exist
    if ActivityLog.query.first():
        logger.info("Activity logs already exist, skipping demo seed")
        return
    
    logger.info("Seeding demo activity logs")
    base_time = datetime.utcnow() - timedelta(hours=2)
    
    demo_logs = [
        {"action": "login", "ip": "192.168.1.100", "minutes_ago": 120, "success": True},
        {"action": "create_token", "ip": "192.168.1.100", "minutes_ago": 115, "success": True},
        {"action": "api_call", "ip": "192.168.1.100", "minutes_ago": 110, "success": True},
        {"action": "api_call", "ip": "10.0.0.50", "minutes_ago": 90, "success": True},
        {"action": "api_call", "ip": "192.168.1.100", "minutes_ago": 60, "success": True},
        {"action": "api_call", "ip": "203.0.113.42", "minutes_ago": 45, "success": False},
        {"action": "logout", "ip": "192.168.1.100", "minutes_ago": 30, "success": True},
    ]
    
    for log_data in demo_logs:
        timestamp = base_time + timedelta(minutes=log_data["minutes_ago"])
        log = ActivityLog(
            account_id=account.id if account else None,
            action=log_data["action"],
            source_ip=log_data["ip"], status="success" if log_data["success"] else "error",
            user_agent="Demo User Agent",
            request_data=json.dumps({"demo": True}),
            
            created_at=timestamp
        )
        db.session.add(log)
    
    db.session.commit()
    logger.info(f"Seeded {len(demo_logs)} demo activity logs")


def seed_mock_email_config() -> None:
    """Seed email config for mock/test mode (uses Mailpit).
    
    This configures the app to send emails to a local Mailpit instance
    which is used during local testing.
    
    Fields are stored with both internal names (smtp_server, sender_email)
    and HTML form names (smtp_host, from_email) for template compatibility.
    """
    from ..models import Settings
    import json
    
    smtp_host = os.environ.get("MOCK_SMTP_HOST", "mailpit")
    smtp_port = int(os.environ.get("MOCK_SMTP_PORT", "1025"))
    from_email = os.environ.get("MOCK_SMTP_FROM", "naf@example.com")
    
    email_config = {
        # Internal field names (used by email_notifier)
        "smtp_server": smtp_host,
        "sender_email": from_email,
        "sender_name": "Netcup API Filter",
        # HTML form field names (used by templates)
        "smtp_host": smtp_host,
        "from_email": from_email,
        "from_name": "Netcup API Filter",
        # Common fields
        "smtp_port": smtp_port,
        "smtp_security": "none",  # Mailpit doesn't use TLS
        "smtp_username": "",  # Mailpit doesn't require auth
        "smtp_password": "",
        "use_ssl": False,
        "reply_to": "",
        "admin_email": os.environ.get("MOCK_ADMIN_EMAIL", "admin@example.com"),
        "notify_new_account": True,
        "notify_realm_request": True,
        "notify_security": True,
    }
    
    setting = Settings.query.filter_by(key="email_config").first()
    if not setting:
        setting = Settings(key="email_config")
        db.session.add(setting)
    setting.value = json.dumps(email_config)
    db.session.commit()
    logger.info(f"Seeded email config for mock mode: {smtp_host}:{smtp_port} from {from_email}")


def seed_default_entities(
    admin_options: AdminSeedOptions | None = None,
    client_options = None,  # Ignored for backwards compat
    seed_demo_clients_flag: bool = False,
    seed_mock_email: bool = False,
) -> Tuple[str | None, str | None, list]:
    """Seed default admin and optionally demo accounts.
    
    Args:
        admin_options: Optional admin account configuration
        client_options: Ignored (backwards compatibility)
        seed_demo_clients_flag: Whether to seed demo accounts
        seed_mock_email: Whether to seed email config for mock mode (Mailpit)
    
    Returns:
        Tuple of (primary_client_id, primary_secret_key, all_demo_clients)
    """
    # Ensure admin account exists
    admin = ensure_admin_account(admin_options or AdminSeedOptions())
    db.session.commit()
    
    # Seed mock email config if requested (for local testing)
    if seed_mock_email:
        seed_mock_email_config()
    
    all_demo_clients: list[Tuple[str, str, str]] = []
    primary_client_id = None
    primary_secret = None
    
    if seed_demo_clients_flag:
        # Get demo account config from env/defaults
        demo_username = os.environ.get('DEFAULT_TEST_CLIENT_ID') or get_default('DEFAULT_TEST_CLIENT_ID', 'demo-user')
        
        # Validate username format
        is_valid, error = validate_username(demo_username)
        if not is_valid:
            # Generate valid username
            demo_username = f"demouser{secrets.token_urlsafe(4)[:4].lower()}"
            logger.warning(f"Demo username invalid, using generated: {demo_username}")
        
        demo_password = "DemoPassword123!"
        
        # Parse realm config
        realm_fqdn = os.environ.get('DEFAULT_TEST_CLIENT_REALM_VALUE') or get_default('DEFAULT_TEST_CLIENT_REALM_VALUE', 'example.com')
        realm_type = os.environ.get('DEFAULT_TEST_CLIENT_REALM_TYPE') or get_default('DEFAULT_TEST_CLIENT_REALM_TYPE', 'host')
        
        # Extract domain from FQDN
        fqdn_parts = realm_fqdn.split('.')
        if len(fqdn_parts) > 2:
            realm_value = '.'.join(fqdn_parts[:-2])
            domain = '.'.join(fqdn_parts[-2:])
        else:
            realm_value = ''
            domain = realm_fqdn
        
        record_types_str = os.environ.get('DEFAULT_TEST_CLIENT_RECORD_TYPES') or get_default('DEFAULT_TEST_CLIENT_RECORD_TYPES', 'A,AAAA')
        record_types = [rt.strip() for rt in record_types_str.split(',')]
        
        operations_str = os.environ.get('DEFAULT_TEST_CLIENT_OPERATIONS') or get_default('DEFAULT_TEST_CLIENT_OPERATIONS', 'read')
        operations = [op.strip() for op in operations_str.split(',')]
        
        # Create demo account options
        demo_options = DemoAccountSeedOptions(
            username=demo_username,
            password=demo_password,
            email=f"{demo_username}@example.com",
            realm=RealmSeedOptions(
                domain=domain,
                realm_type=realm_type,
                realm_value=realm_value,
                record_types=record_types,
                operations=operations
            ),
            token=TokenSeedOptions(
                token_name='primary-token',
                description='Primary demo token'
            )
        )
        
        # Create account
        demo_account = ensure_account(demo_options, approved_by=admin)
        db.session.flush()
        
        # Create realm
        realm = ensure_realm(demo_account, demo_options.realm, approved_by=admin)
        db.session.flush()
        
        # Create token
        token, plain_token = ensure_token(realm, demo_options.token)
        db.session.commit()
        
        if plain_token:
            primary_client_id = demo_username
            primary_secret = plain_token
            all_demo_clients.append((demo_username, plain_token, "Primary demo account"))
            logger.info(f"Created demo account: {demo_username} with token")
        
        # Seed demo activity logs
        seed_demo_audit_logs(demo_account)
    
    return primary_client_id, primary_secret, all_demo_clients


def seed_from_config(config: dict) -> None:
    """Apply structured config to the database.
    
    This is for backwards compatibility - new schema uses database Settings.
    """
    from ..models import Settings
    import json
    
    netcup_config = config.get("netcup")
    if netcup_config:
        logger.info("Applying Netcup API configuration from config")
        setting = Settings.query.filter_by(key="netcup_config").first()
        if not setting:
            setting = Settings(key="netcup_config")
            db.session.add(setting)
        setting.value = json.dumps({
            "customer_id": netcup_config.get("customer_id", ""),
            "api_key": netcup_config.get("api_key", ""),
            "api_password": netcup_config.get("api_password", ""),
            "api_url": netcup_config.get(
                "api_url",
                "https://ccp.netcup.net/run/webservice/servers/endpoint.php?JSON",
            ),
            "timeout": int(netcup_config.get("timeout", 30)),
        })
        db.session.commit()
    
    # Legacy token import not supported - use admin UI instead
    tokens = config.get("tokens", [])
    if tokens:
        logger.warning("Token import from config not supported in new schema - use admin UI")


def seed_comprehensive_demo_data(admin: Account) -> None:
    """Seed comprehensive demo data for UI screenshots and testing.
    
    This creates:
    - 6 accounts in different states (active, pending, disabled)
    - Multiple realms per account in different states (approved, pending, rejected)
    - Multiple tokens in different states (active, expired, revoked)
    - Comprehensive activity logs covering all event types
    
    Call this from build_deployment.py with --seed-demo flag.
    """
    import json
    from datetime import timedelta
    from ..models import AccountRealm, APIToken, ActivityLog
    
    logger.info("=== Seeding Comprehensive Demo Data ===")
    
    # Skip if demo data already exists (check for demo-active account)
    if Account.query.filter_by(username="demo-active").first():
        logger.info("Demo data already exists, skipping")
        return
    
    # =========================================================================
    # 1. Create Demo Accounts with Various States
    # =========================================================================
    
    demo_accounts = [
        {"username": "demo-active", "email": "active@demo.example.com", 
         "is_active": True, "email_verified": True, "approved": True},
        {"username": "demo-pending-approval", "email": "pending@demo.example.com",
         "is_active": False, "email_verified": True, "approved": False},
        {"username": "demo-pending-email", "email": "unverified@demo.example.com",
         "is_active": False, "email_verified": False, "approved": False},
        {"username": "demo-disabled", "email": "disabled@demo.example.com",
         "is_active": False, "email_verified": True, "approved": True},
        {"username": "demo-power-user", "email": "power@demo.example.com",
         "is_active": True, "email_verified": True, "approved": True},
        {"username": "demo-readonly", "email": "readonly@demo.example.com",
         "is_active": True, "email_verified": True, "approved": True},
    ]
    
    created_accounts = {}
    for acc_data in demo_accounts:
        # Generate unique user_alias for token attribution
        user_alias = generate_user_alias()
        account = Account(
            username=acc_data["username"],
            user_alias=user_alias,
            email=acc_data["email"],
            email_verified=1 if acc_data["email_verified"] else 0,
            is_active=1 if acc_data["is_active"] else 0,
            is_admin=0,
            approved_by_id=admin.id if acc_data["approved"] else None,
            approved_at=datetime.utcnow() if acc_data["approved"] else None,
            created_at=datetime.utcnow() - timedelta(days=30)
        )
        account.set_password("DemoPassword123!")
        db.session.add(account)
        created_accounts[acc_data["username"]] = account
        logger.info(f"Created account: {acc_data['username']} (alias: {user_alias[:4]}...)")
    
    db.session.flush()
    
    # =========================================================================
    # 2. Create Realms with Various States
    # =========================================================================
    
    demo_realms = [
        # demo-active: 2 approved realms
        {"account": "demo-active", "domain": "example.com", "realm_type": "host",
         "realm_value": "home", "status": "approved",
         "record_types": ["A", "AAAA"], "operations": ["read", "update"]},
        {"account": "demo-active", "domain": "example.com", "realm_type": "subdomain",
         "realm_value": "iot", "status": "approved",
         "record_types": ["A", "AAAA", "TXT", "CNAME"], "operations": ["read", "create", "update", "delete"]},
        
        # demo-power-user: 5 realms (various states)
        {"account": "demo-power-user", "domain": "vxxu.de", "realm_type": "subdomain_only",
         "realm_value": "client1", "status": "approved",
         "record_types": ["A", "AAAA", "TXT"], "operations": ["read", "create", "update", "delete"]},
        {"account": "demo-power-user", "domain": "example.com", "realm_type": "host",
         "realm_value": "vpn", "status": "approved",
         "record_types": ["A", "AAAA"], "operations": ["read", "update"]},
        {"account": "demo-power-user", "domain": "example.com", "realm_type": "subdomain",
         "realm_value": "acme", "status": "pending",
         "record_types": ["TXT"], "operations": ["create", "delete"]},
        {"account": "demo-power-user", "domain": "example.com", "realm_type": "host",
         "realm_value": "rejected", "status": "rejected",
         "record_types": ["A"], "operations": ["read"]},
        {"account": "demo-power-user", "domain": "example.com", "realm_type": "host",
         "realm_value": "revoked", "status": "rejected",
         "record_types": ["A"], "operations": ["read"]},
        
        # demo-disabled: 1 revoked realm
        {"account": "demo-disabled", "domain": "example.com", "realm_type": "host",
         "realm_value": "old", "status": "rejected",
         "record_types": ["A"], "operations": ["read"]},
        
        # demo-readonly: 1 read-only realm
        {"account": "demo-readonly", "domain": "example.com", "realm_type": "host",
         "realm_value": "monitor", "status": "approved",
         "record_types": ["A", "AAAA", "TXT", "MX"], "operations": ["read"]},
    ]
    
    created_realms = {}
    for realm_data in demo_realms:
        account = created_accounts[realm_data["account"]]
        realm_key = f"{realm_data['realm_type']}:{realm_data['realm_value']}@{realm_data['domain']}"
        
        realm = AccountRealm(
            account_id=account.id,
            domain=realm_data["domain"],
            realm_type=realm_data["realm_type"],
            realm_value=realm_data["realm_value"],
            status=realm_data["status"],
            requested_at=datetime.utcnow() - timedelta(days=25),
            approved_by_id=admin.id if realm_data["status"] == "approved" else None,
            approved_at=datetime.utcnow() - timedelta(days=20) if realm_data["status"] == "approved" else None
        )
        realm.set_allowed_record_types(realm_data["record_types"])
        realm.set_allowed_operations(realm_data["operations"])
        db.session.add(realm)
        created_realms[realm_key] = realm
        logger.info(f"Created realm: {realm_key} ({realm_data['status']})")
    
    db.session.flush()
    
    # =========================================================================
    # 3. Create Tokens with Various States
    # =========================================================================
    
    demo_tokens = [
        # demo-active tokens
        {"realm_key": "host:home@example.com", "token_name": "home-router",
         "description": "Home router DDNS", "is_active": True, "expires": None,
         "ip_ranges": ["192.168.1.0/24"]},
        {"realm_key": "host:home@example.com", "token_name": "backup-updater",
         "description": "Backup updater with expiry", "is_active": True, 
         "expires": datetime.utcnow() + timedelta(days=365),
         "ip_ranges": None},
        {"realm_key": "subdomain:iot@example.com", "token_name": "fleet-manager",
         "description": "IoT fleet manager full access", "is_active": True,
         "expires": None, "ip_ranges": None},
        {"realm_key": "subdomain:iot@example.com", "token_name": "monitoring",
         "description": "Monitoring read-only", "is_active": True,
         "expires": None, "ip_ranges": None,
         "record_types_override": ["A", "AAAA"], "operations_override": ["read"]},
        
        # demo-power-user tokens
        {"realm_key": "subdomain_only:client1@vxxu.de", "token_name": "certbot-prod",
         "description": "Certbot production DNS-01", "is_active": True,
         "expires": None, "ip_ranges": None},
        {"realm_key": "subdomain_only:client1@vxxu.de", "token_name": "certbot-staging",
         "description": "Certbot staging (EXPIRED)", "is_active": False,
         "expires": datetime.utcnow() - timedelta(days=30), "ip_ranges": None},
        {"realm_key": "subdomain_only:client1@vxxu.de", "token_name": "old-system",
         "description": "Old system (REVOKED)", "is_active": False,
         "expires": None, "ip_ranges": None},
        {"realm_key": "host:vpn@example.com", "token_name": "vpn-gateway",
         "description": "VPN gateway updater", "is_active": True,
         "expires": None, "ip_ranges": ["10.0.0.0/8"]},
        {"realm_key": "host:vpn@example.com", "token_name": "vpn-backup",
         "description": "VPN backup (never used)", "is_active": True,
         "expires": None, "ip_ranges": None},
        
        # demo-readonly token
        {"realm_key": "host:monitor@example.com", "token_name": "grafana",
         "description": "Grafana dashboard read-only", "is_active": True,
         "expires": None, "ip_ranges": ["10.0.0.0/8"]},
    ]
    
    created_tokens = {}
    for token_data in demo_tokens:
        realm_key = token_data["realm_key"]
        if realm_key not in created_realms:
            logger.warning(f"Skipping token {token_data['token_name']} - realm {realm_key} not found")
            continue
        
        realm = created_realms[realm_key]
        account = realm.account
        
        # Generate token using user_alias (not username for security)
        full_token = generate_token(account.user_alias)
        # Token format: naf_<user_alias>_<random64> where user_alias is 16 chars
        random_part_start = 4 + USER_ALIAS_LENGTH + 1  # "naf_" + alias + "_"
        token_prefix = full_token[random_part_start:random_part_start + 8]
        
        token = APIToken(
            realm_id=realm.id,
            token_name=token_data["token_name"],
            token_description=token_data["description"],
            token_prefix=token_prefix,
            token_hash=hash_token(full_token),
            is_active=1 if token_data["is_active"] else 0,
            expires_at=token_data.get("expires"),
            created_at=datetime.utcnow() - timedelta(days=15)
        )
        
        # Optional overrides
        if token_data.get("record_types_override"):
            token.set_allowed_record_types(token_data["record_types_override"])
        if token_data.get("operations_override"):
            token.set_allowed_operations(token_data["operations_override"])
        if token_data.get("ip_ranges"):
            token.set_allowed_ip_ranges(token_data["ip_ranges"])
        
        db.session.add(token)
        created_tokens[token_data["token_name"]] = token
        logger.info(f"Created token: {token_data['token_name']} ({realm_key})")
    
    db.session.flush()
    
    # =========================================================================
    # 4. Create Activity Logs covering all event types
    # =========================================================================
    
    base_time = datetime.utcnow() - timedelta(hours=48)
    
    activity_logs = [
        # Admin login events
        {"action": "admin_login", "ip": "192.168.1.100", "hours_ago": 48,
         "success": True, "details": {"username": "admin"}},
        {"action": "admin_login", "ip": "203.0.113.42", "hours_ago": 47,
         "success": False, "details": {"username": "admin", "reason": "invalid_password"}},
        
        # Account registration
        {"action": "account_register", "ip": "198.51.100.10", "hours_ago": 46,
         "success": True, "account": "demo-active", "details": {"email": "active@demo.example.com"}},
        {"action": "account_verify_email", "ip": "198.51.100.10", "hours_ago": 45,
         "success": True, "account": "demo-active", "details": {}},
        {"action": "account_approved", "ip": "192.168.1.100", "hours_ago": 44,
         "success": True, "account": "demo-active", "details": {"approved_by": "admin"}},
        
        # Realm requests
        {"action": "realm_request", "ip": "198.51.100.10", "hours_ago": 43,
         "success": True, "account": "demo-active", "details": {"realm": "host:home@example.com"}},
        {"action": "realm_approved", "ip": "192.168.1.100", "hours_ago": 42,
         "success": True, "account": "demo-active", "details": {"realm": "host:home@example.com"}},
        {"action": "realm_request", "ip": "198.51.100.20", "hours_ago": 30,
         "success": True, "account": "demo-power-user", "details": {"realm": "subdomain:acme@example.com"}},
        {"action": "realm_rejected", "ip": "192.168.1.100", "hours_ago": 29,
         "success": True, "account": "demo-power-user", 
         "details": {"realm": "host:rejected@example.com", "reason": "Domain not verified"}},
        
        # Token operations
        {"action": "token_create", "ip": "198.51.100.10", "hours_ago": 41,
         "success": True, "account": "demo-active", 
         "details": {"token_name": "home-router", "realm": "host:home@example.com"}},
        {"action": "token_revoke", "ip": "198.51.100.20", "hours_ago": 20,
         "success": True, "account": "demo-power-user",
         "details": {"token_name": "old-system", "reason": "Security rotation"}},
        
        # API calls - successful
        {"action": "api_call", "ip": "192.168.1.1", "hours_ago": 36,
         "success": True, "account": "demo-active", "token": "home-router",
         "details": {"operation": "read", "domain": "example.com", "record": "home.example.com", "type": "A"}},
        {"action": "api_call", "ip": "192.168.1.1", "hours_ago": 24,
         "success": True, "account": "demo-active", "token": "home-router",
         "details": {"operation": "update", "domain": "example.com", "record": "home.example.com", "type": "A", "value": "1.2.3.4"}},
        {"action": "api_call", "ip": "10.0.0.50", "hours_ago": 12,
         "success": True, "account": "demo-active", "token": "fleet-manager",
         "details": {"operation": "create", "domain": "example.com", "record": "sensor1.iot.example.com", "type": "A"}},
        {"action": "api_call", "ip": "52.94.76.8", "hours_ago": 6,
         "success": True, "account": "demo-power-user", "token": "certbot-prod",
         "details": {"operation": "create", "domain": "vxxu.de", "record": "_acme-challenge.client1.vxxu.de", "type": "TXT"}},
        {"action": "api_call", "ip": "52.94.76.8", "hours_ago": 5,
         "success": True, "account": "demo-power-user", "token": "certbot-prod",
         "details": {"operation": "delete", "domain": "vxxu.de", "record": "_acme-challenge.client1.vxxu.de", "type": "TXT"}},
        
        # API calls - denied
        {"action": "api_call", "ip": "203.0.113.50", "hours_ago": 18,
         "success": False, "account": "demo-readonly", "token": "grafana",
         "details": {"operation": "update", "reason": "read-only token", "domain": "example.com"}},
        {"action": "api_call", "ip": "123.45.67.89", "hours_ago": 15,
         "success": False, "account": "demo-active", "token": "home-router",
         "details": {"operation": "update", "reason": "IP not in whitelist", "source_ip": "123.45.67.89"}},
        
        # API auth failures
        {"action": "api_auth_failure", "ip": "185.220.101.42", "hours_ago": 10,
         "success": False, "details": {"reason": "invalid_token"}},
        {"action": "api_auth_failure", "ip": "195.54.160.12", "hours_ago": 8,
         "success": False, "details": {"reason": "expired_token", "token_prefix": "abc12345"}},
        
        # Password changes
        {"action": "password_change", "ip": "198.51.100.10", "hours_ago": 2,
         "success": True, "account": "demo-active", "details": {}},
        
        # Account disabled
        {"action": "account_disabled", "ip": "192.168.1.100", "hours_ago": 1,
         "success": True, "account": "demo-disabled", "details": {"reason": "Inactive for 90 days"}},
    ]
    
    for log_data in activity_logs:
        timestamp = base_time + timedelta(hours=(48 - log_data["hours_ago"]))
        
        account = created_accounts.get(log_data.get("account"))
        token = created_tokens.get(log_data.get("token"))
        
        log = ActivityLog(
            account_id=account.id if account else None,
            token_id=token.id if token else None,
            action=log_data["action"],
            source_ip=log_data["ip"],
            status="success" if log_data["success"] else "error",
            user_agent="Mozilla/5.0 Demo User Agent",
            request_data=json.dumps(log_data["details"]),
            created_at=timestamp
        )
        db.session.add(log)
    
    db.session.commit()
    logger.info(f"Created {len(activity_logs)} activity log entries")
    
    logger.info("=== Comprehensive Demo Data Seeding Complete ===")
    logger.info(f"  Accounts: {len(demo_accounts)}")
    logger.info(f"  Realms: {len(demo_realms)}")
    logger.info(f"  Tokens: {len(demo_tokens)}")
    logger.info(f"  Activity logs: {len(activity_logs)}")
